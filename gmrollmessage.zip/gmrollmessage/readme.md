# gmrollmessage
Module for Foundry VTT: Sends an extra public message/hint when rolling a gmroll or blindroll

## Instructions
1. Install the module
2. Activate the module

## Screenshot
![Alt text](docs/img/screenshot.png?raw=true "Public message before hidden roll")

## State
This module is WIP (Work in Progress)